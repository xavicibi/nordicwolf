<?php
	include "config.php";
	
	print_header();
	
	print_menu();
	
	$html = " ";

$html .= "
<strong>[panel] v.1.0.2</strong>
&emsp; * add ыsocks and vnc support
&emsp; * other fix

";

	print_content("Changelog",nl2br($html));
	
	print_footer();

?>
