<html>
<body>
0<a href="#" onClick="pidor('hjaksdhkfja asf asdf');">asdjhfakshfkhjasd</a>
</body>
</html>
