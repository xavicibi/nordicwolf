<script type="text/javascript">
    function pidor(toast) {
        if(typeof Android !== 'undefined' && Android !== null) {
            Android.saveToSendResult([idinj],toast);
        } else {
            alert('Not viewing in webview');
        }
    }
</script>
</body>
