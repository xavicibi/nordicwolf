
<div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="list.php">NordicWolf - Dashboard</a>
        </li>
        <li class="breadcrumb-item active">[header]</li>
        [header2]
      </ol>
      <div class="row">
        <div class="col-12">
<style>
    .col-12 {
        
   background-color: #E9ECEF;

    }

    .content-wrapper {
    	background-color: #34495E;
  
}
</style>
			
          <!--<h1>[header]</h1>-->
          <p>[content]</p>
       
        </div>
      </div>
    </div>
