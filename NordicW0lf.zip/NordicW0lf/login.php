<?php
	include "config.php";

	if($dbm->check_auth($_SESSION['key'])){
		header("Location: list.php");
		die();
	}

	if(isset($_POST['login']) && isset($_POST['password'])){

		if($dbm->auth($_POST['login'],$_POST['password'])){
			header("Location: list.php");
			die();
		}
	}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Nordic Wolf - Android Botnet</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
  <link rel="icon" href="images/favicon.ico">
  <script>alert('Welcome to Nordic Wolf Android Banking Botnet')</script>
</head>

<body class="bg-dark">
  <div class="container">
  	<div align="center"><img src="logowolf.png" width="200" height="220"></div>
    <div class="card card-login mx-auto mt-10">
    <font color="white" />
      <div class="card-header" style="background:#4F5252">Nordic Wolf Android Banking Botnet - Login</div>
      <div class="card-body">
        <form class="form-signin" style="background:#4F5252" method="POST" id="form-id">
          <div class="form-group">
            <label for="exampleInputEmail1">Username:</label>
            <input name="login" class="form-control" id="exampleInputEmail1" type="email" aria-describedby="emailHelp" placeholder="Enter your Username">
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Password:</label>
            <input name="password" class="form-control" id="exampleInputPassword1" type="password" placeholder="Password">
          </div>
          <a class="btn btn-primary btn-block" style="background:#4F5252" onclick="document.getElementById('form-id').submit();">Login to Nordic Wolf Botnet</a>
        </form>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <style type="text/css">
body{
background: url(nordicwolf.jpg) no-repeat center center fixed;
-webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover;
}
  </style>
</body>

</html>

