
<?php
	include "config.php";
	
	print_header();
	
	print_menu();
	
	$html = " ";

	print_content("Faq",$html);
	
	print_footer();

?>
