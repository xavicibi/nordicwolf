<?php
	include "config.php";

	if($auth){
		header("Location: list.php");
	}
?>
