<?php
function new_time($a) { // New Time of NordicWolf
 date_default_timezone_set('Europe/Germany');
 $ndate = date('d.m.Y', $a);
 $ndate_time = date('H:i', $a);
 $ndate_exp = explode('.', $ndate);
 $nmonth = array(
 );

 foreach ($nmonth as $key => $value) {
  if($key == intval($ndate_exp[1])) $nmonth_name = $value;
 }

if($ndate == date('d.m.Y')) return 'сегодня в '.$ndate_time;
 elseif($ndate == date('d.m.Y', strtotime('-1 day'))) return 'вчера в '.$ndate_time;
 else return $ndate_exp[0].' '.$nmonth_name.' '.$ndate_exp[2].' в '.$ndate_time;
}

?>
