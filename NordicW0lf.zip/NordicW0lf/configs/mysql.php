<?php

	$mysql['host'] = "localhost";
	$mysql['db'] = "nordicwolf";
	$mysql['user'] = "nordicwolf";
	$mysql['pass'] = "Anonxcr7%";
	
?>
